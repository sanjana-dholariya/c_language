#include<stdio.h>

main()
{
	int n;
	printf("enter the size of string:");
	scanf("%d",&n);
	char pass[n];
	int i;
	printf("enter your password:");
	scanf("%s",&pass);
	if(pass[n]>=65 && pass[n]<=90)
	{
	 pass[n]=pass[n]+32;
	printf("your password is: %s",pass);
   }
}
